package com.mqdanh.tool

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import org.json.JSONArray

class MainActivity : Activity() {
    private val msgs = mutableListOf<String>()
    private lateinit var listBox: LinearLayout
    private lateinit var speedTxt: TextView
    private lateinit var status: TextView
    private lateinit var seek: SeekBar
    private lateinit var loopSw: Switch
    private val pink = Color.parseColor("#48484A")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int, r: Int) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(c) }
    private fun prefs() = getSharedPreferences("mq", MODE_PRIVATE)

    private fun label(s: String, size: Float = 13f, color: Int = Color.parseColor("#8E8E93"), bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(16))
        background = round(Color.WHITE, 20)
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(14) }
    }

    private fun pill(s: String, bg: Int, fg: Int, onClick: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; textSize = 16f; setTextColor(fg)
        typeface = Typeface.DEFAULT_BOLD
        background = round(bg, 14); stateListAnimator = null
        layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(50)).apply { topMargin = dp(10) }
        setOnClickListener { onClick() }
    }

    private fun speedText(p: Int) = String.format("%.1f giây", 0.5 + p / 10.0).replace('.', ',')

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val arr = JSONArray(prefs().getString("msgs", "[]"))
        for (i in 0 until arr.length()) msgs.add(arr.getString(i))
        window.statusBarColor = Color.parseColor("#F2F2F7")
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val scroll = ScrollView(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#F2F2F7"), Color.parseColor("#F2F2F7")))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(32))
        }
        scroll.addView(root)
        root.addView(label("MQDANH TOOL", 34f, Color.parseColor("#1C1C1E"), true))
        root.addView(label("Buy Tele: @qdanhne", 15f, pink, true))
        root.addView(label("Tự động gửi tin nhắn", 15f))

        val c1 = card()
        c1.addView(label("NỘI DUNG"))
        val input = EditText(this).apply {
            hint = "Nhập tin nhắn..."; textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            background = round(Color.parseColor("#F2F2F7"), 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) }
        }
        c1.addView(input)
        c1.addView(pill("+ Thêm vào danh sách", pink, Color.WHITE) {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { msgs.add(t); input.setText(""); refresh() }
        })
        root.addView(c1)

        val c2 = card()
        c2.addView(label("DANH SÁCH (chạm để xóa)"))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c2.addView(listBox)
        root.addView(c2)

        val c3 = card()
        c3.addView(label("TỐC ĐỘ GỬI (0,5s – 10s)"))
        speedTxt = label("", 22f, pink, true)
        c3.addView(speedTxt)
        seek = SeekBar(this).apply {
            max = 95; progress = prefs().getInt("speed", 5)
            progressTintList = ColorStateList.valueOf(pink)
            thumbTintList = ColorStateList.valueOf(pink)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { speedTxt.text = speedText(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        speedTxt.text = speedText(seek.progress)
        c3.addView(seek)
        loopSw = Switch(this).apply {
            text = "Lặp lại danh sách"; textSize = 16f
            isChecked = prefs().getBoolean("loop", false)
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) }
        }
        c3.addView(loopSw)
        root.addView(c3)

        status = label("", 14f, Color.parseColor("#3C3C43")).apply {
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(16) }
        }
        root.addView(status)

        root.addView(pill("Bắt đầu", pink, Color.WHITE) { startTool() })
        root.addView(pill("Bật dịch vụ Trợ năng", Color.parseColor("#E5E5EA"), pink) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(label("Cách dùng: bật Trợ năng → Bắt đầu → mở app chat, chạm vào ô nhập để hiện bàn phím → bấm nút nổi \"▶ Bắt đầu\". Kéo nút để di chuyển. Nút \"✎ Vẽ\" cho phép vẽ lên màn hình, \"Màu nét\" đổi màu, \"Xóa nét vẽ\" để xóa.", 13f).apply {
            setPadding(0, dp(14), 0, 0)
        })
        setContentView(scroll)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        status.text = if (SenderService.instance != null) "● Dịch vụ đã sẵn sàng" else "○ Chưa bật dịch vụ Trợ năng"
    }

    private fun refresh() {
        listBox.removeAllViews()
        if (msgs.isEmpty()) listBox.addView(label("Chưa có tin nhắn nào", 15f).apply { setPadding(0, dp(8), 0, 0) })
        msgs.forEachIndexed { i, m ->
            listBox.addView(TextView(this).apply {
                text = "${i + 1}. $m"; textSize = 16f; setTextColor(Color.parseColor("#1C1C1E"))
                setPadding(dp(4), dp(10), dp(4), dp(10))
                setOnClickListener { msgs.removeAt(i); refresh() }
            })
        }
        save()
    }

    private fun save() {
        prefs().edit()
            .putString("msgs", JSONArray(msgs).toString())
            .putInt("speed", seek.progress)
            .putBoolean("loop", loopSw.isChecked)
            .apply()
    }

    private fun startTool() {
        save()
        val svc = SenderService.instance
        if (svc == null) {
            Toast.makeText(this, "Hãy bật MQDANH TOOL trong Trợ năng", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
        }
        if (msgs.isEmpty()) { Toast.makeText(this, "Thêm ít nhất 1 tin nhắn", Toast.LENGTH_SHORT).show(); return }
        svc.showOverlay()
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
