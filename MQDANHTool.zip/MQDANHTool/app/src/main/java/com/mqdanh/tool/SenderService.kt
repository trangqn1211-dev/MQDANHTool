package com.mqdanh.tool

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.res.ColorStateList
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

class SenderService : AccessibilityService() {
    companion object { var instance: SenderService? = null }

    private val h = Handler(Looper.getMainLooper())
    private var panel: LinearLayout? = null
    private var bubble: TextView? = null
    private var stateTxt: TextView? = null
    private var running = false
    private var idx = 0
    private var posX = 0
    private var posY = 0
    private val pink = Color.parseColor("#FF4D94")

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean {
        stop(); hideOverlay(); instance = null
        return super.onUnbind(intent)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun wm() = getSystemService(WINDOW_SERVICE) as WindowManager
    private fun prefs() = getSharedPreferences("mq", MODE_PRIVATE)
    private fun speedText(p: Int) = String.format("%.1f giây", 0.3 + p / 10.0).replace('.', ',')

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = posX; y = posY }

    private fun draggable(target: View, handle: View, onTap: (() -> Unit)?) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = posX; oy = posY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    if (moved) {
                        posX = ox + dx; posY = oy + dy
                        val l = target.layoutParams as WindowManager.LayoutParams
                        l.x = posX; l.y = posY
                        wm().updateViewLayout(target, l)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
            }
            true
        }
    }

    fun showOverlay() {
        if (panel != null || bubble != null) return
        posX = dp(16); posY = dp(180)
        openMenu()
    }

    private fun removeSafe(v: View?) { try { if (v != null) wm().removeView(v) } catch (_: Exception) {} }

    private fun openMenu() {
        removeSafe(bubble); bubble = null
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(14))
            background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(pink) }
        }
        val head = TextView(this).apply {
            text = "≡  MQDANH TOOL"; setTextColor(Color.WHITE); textSize = 16f
            typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(4), 0, dp(6))
        }
        box.addView(head)

        fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; setTextColor(pink); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(Color.WHITE) }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
            setOnClickListener { onClick() }
        }
        box.addView(btn("▶  Bắt đầu chạy") { start() })
        box.addView(btn("■  Dừng chạy") { stop() })

        val speed = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; setPadding(0, dp(12), 0, 0)
            text = "Tốc độ: " + speedText(prefs().getInt("speed", 5))
        }
        box.addView(speed)
        box.addView(SeekBar(this).apply {
            max = 97; progress = prefs().getInt("speed", 5)
            progressTintList = ColorStateList.valueOf(Color.WHITE)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    speed.text = "Tốc độ: " + speedText(p)
                    prefs().edit().putInt("speed", p).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        stateTxt = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; setPadding(0, dp(4), 0, 0)
            text = if (running) "Đang chạy…" else "Đã dừng"
        }
        box.addView(stateTxt)
        box.addView(btn("✕  Đóng menu") { closeMenu() })

        val l = params(dp(240), WindowManager.LayoutParams.WRAP_CONTENT)
        box.layoutParams = l
        draggable(box, head, null)
        wm().addView(box, l)
        panel = box
    }

    private fun closeMenu() {
        removeSafe(panel); panel = null; stateTxt = null
        val b = TextView(this).apply {
            text = "MQ"; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(pink) }
        }
        val l = params(dp(54), dp(54))
        b.layoutParams = l
        draggable(b, b) { openMenu() }
        wm().addView(b, l)
        bubble = b
    }

    fun hideOverlay() {
        removeSafe(panel); removeSafe(bubble)
        panel = null; bubble = null; stateTxt = null
    }

    private fun start() {
        h.removeCallbacks(tick)
        running = true; idx = 0
        stateTxt?.text = "Đang chạy…"
        h.post(tick)
    }

    private fun stop() {
        running = false
        h.removeCallbacks(tick)
        stateTxt?.text = "Đã dừng"
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val arr = JSONArray(prefs().getString("msgs", "[]"))
            if (arr.length() == 0) { stop(); return }
            if (idx >= arr.length()) {
                if (prefs().getBoolean("loop", false)) idx = 0 else { stop(); return }
            }
            if (!sendOne(arr.getString(idx))) {
                Toast.makeText(this@SenderService, "Hãy bấm vào ô nhập tin nhắn trước", Toast.LENGTH_SHORT).show()
                stop(); return
            }
            idx++
            h.postDelayed(this, 300L + prefs().getInt("speed", 5) * 100L)
        }
    }

    private fun compose(msg: String): String {
        val name = (prefs().getString("name", "") ?: "").trim().removePrefix("@").trim()
        if (name.isEmpty()) return msg
        return if (prefs().getBoolean("tag", false)) "@$name $msg" else "$name ơi, $msg"
    }

    private fun sendOne(text: String): Boolean {
        val input = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, compose(text))
        }
        if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return false
        h.postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            val btn = findSend(root)
            if (btn != null) {
                var n: AccessibilityNodeInfo? = btn
                while (n != null && !n.isClickable) n = n.parent
                n?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            } else if (Build.VERSION.SDK_INT >= 30) {
                root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                    ?.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            }
        }, 150)
        return true
    }

    private val sendRe = Regex("(?i)(send|send message|gửi|gửi tin nhắn|gui)")

    private fun findSend(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        val d = n.contentDescription?.toString()?.trim()
        val t = n.text?.toString()?.trim()
        val id = n.viewIdResourceName ?: ""
        if ((d != null && sendRe.matches(d)) || (t != null && sendRe.matches(t)) ||
            id.contains("send", true)) return n
        for (i in 0 until n.childCount) findSend(n.getChild(i))?.let { return it }
        return null
    }
}
