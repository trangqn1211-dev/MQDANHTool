package com.mqdanh.tool

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

class SenderService : AccessibilityService() {
    companion object { var instance: SenderService? = null }

    private val h = Handler(Looper.getMainLooper())
    private var overlay: TextView? = null
    private var running = false
    private var idx = 0
    private lateinit var lp: WindowManager.LayoutParams

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean {
        stop(); hideOverlay(); instance = null
        return super.onUnbind(intent)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private var panel: LinearLayout? = null
    private var drawView: DrawView? = null
    private lateinit var drawLp: WindowManager.LayoutParams
    private var drawing = false
    private val colors = intArrayOf(
        Color.parseColor("#FF3B30"), Color.parseColor("#007AFF"), Color.parseColor("#34C759"),
        Color.parseColor("#FFCC00"), Color.WHITE, Color.BLACK
    )
    private var colorIdx = 0

    inner class DrawView(ctx: Context) : View(ctx) {
        private val strokes = mutableListOf<Pair<Path, Int>>()
        private var cur: Path? = null
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = dp(5).toFloat()
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        var color = colors[0]
        fun clear() { strokes.clear(); cur = null; invalidate() }
        override fun onDraw(c: Canvas) {
            for ((p, col) in strokes) { paint.color = col; c.drawPath(p, paint) }
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    val p = Path(); p.moveTo(e.x, e.y); p.lineTo(e.x + 0.1f, e.y)
                    strokes.add(Pair(p, color)); cur = p
                }
                MotionEvent.ACTION_MOVE -> cur?.lineTo(e.x, e.y)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> cur = null
            }
            invalidate(); return true
        }
    }

    fun showOverlay() {
        if (panel != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val dv = DrawView(this)
        drawLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(dv, drawLp)
        drawView = dv

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(200) }

        fun pill(label: String, bg: Int, onClick: (TextView) -> Unit): TextView {
            val t = TextView(this).apply {
                text = label; setTextColor(Color.WHITE); textSize = 14f
                setPadding(dp(16), dp(10), dp(16), dp(10))
                background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(bg) }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
            }
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            t.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                        if (moved) { lp.x = ox + dx; lp.y = oy + dy; wm.updateViewLayout(box, lp) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) onClick(v as TextView)
                }
                true
            }
            return t
        }

        val startBtn = pill("▶ Bắt đầu", Color.parseColor("#48484A")) { if (running) stop() else start() }
        val penBtn = pill("✎ Vẽ: Tắt", Color.parseColor("#8E8E93")) { b ->
            drawing = !drawing
            drawLp.flags = if (drawing) drawLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                           else drawLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(dv, drawLp)
            b.text = if (drawing) "✎ Vẽ: Bật" else "✎ Vẽ: Tắt"
        }
        val colorBtn = pill("Màu nét", colors[0]) { b ->
            colorIdx = (colorIdx + 1) % colors.size
            dv.color = colors[colorIdx]
            (b.background as GradientDrawable).setColor(colors[colorIdx])
            b.setTextColor(if (colors[colorIdx] == Color.WHITE || colors[colorIdx] == Color.parseColor("#FFCC00")) Color.BLACK else Color.WHITE)
        }
        val clearBtn = pill("Xóa nét vẽ", Color.parseColor("#8E8E93")) { dv.clear() }
        box.addView(startBtn); box.addView(penBtn); box.addView(colorBtn); box.addView(clearBtn)
        wm.addView(box, lp)
        panel = box
        overlay = startBtn
    }

    fun hideOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        panel?.let { wm.removeView(it) }
        drawView?.let { wm.removeView(it) }
        panel = null; drawView = null; overlay = null; drawing = false
    }

    private fun prefs() = getSharedPreferences("mq", MODE_PRIVATE)

    private fun start() {
        running = true; idx = 0
        overlay?.text = "■ Dừng"
        h.post(tick)
    }

    private fun stop() {
        running = false
        h.removeCallbacks(tick)
        overlay?.text = "▶ Bắt đầu"
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val arr = JSONArray(prefs().getString("msgs", "[]"))
            if (arr.length() == 0) { stop(); return }
            if (idx >= arr.length()) {
                if (prefs().getBoolean("loop", false)) idx = 0 else { stop(); return }
            }
            if (!sendOne(arr.getString(idx))) {
                Toast.makeText(this@SenderService, "Hãy bấm vào ô nhập tin nhắn trước", Toast.LENGTH_SHORT).show()
                stop(); return
            }
            idx++
            h.postDelayed(this, 500L + prefs().getInt("speed", 5) * 100L)
        }
    }

    private fun sendOne(text: String): Boolean {
        val input = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return false
        h.postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            val btn = findSend(root)
            if (btn != null) {
                var n: AccessibilityNodeInfo? = btn
                while (n != null && !n.isClickable) n = n.parent
                n?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            } else if (Build.VERSION.SDK_INT >= 30) {
                root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                    ?.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            }
        }, 200)
        return true
    }

    private val sendRe = Regex("(?i)(send|send message|gửi|gửi tin nhắn|gui)")

    private fun findSend(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        val d = n.contentDescription?.toString()?.trim()
        val t = n.text?.toString()?.trim()
        val id = n.viewIdResourceName ?: ""
        if ((d != null && sendRe.matches(d)) || (t != null && sendRe.matches(t)) ||
            id.contains("send", true)) return n
        for (i in 0 until n.childCount) findSend(n.getChild(i))?.let { return it }
        return null
    }
}
