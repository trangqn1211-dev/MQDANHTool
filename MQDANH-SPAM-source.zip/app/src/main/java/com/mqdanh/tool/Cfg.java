package com.mqdanh.tool;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class Cfg {
    static final int MIN_MS = 200;
    static final int MAX_MS = 10000;
    private static final String SEP = "\u0001";

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("mqdanh", Context.MODE_PRIVATE);
    }

    static List<String> messages(Context c) {
        List<String> out = new ArrayList<>();
        String s = p(c).getString("msgs", "");
        for (String m : s.split(SEP)) {
            if (!m.trim().isEmpty()) out.add(m);
        }
        return out;
    }

    static void saveMessages(Context c, List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(SEP);
            sb.append(list.get(i));
        }
        p(c).edit().putString("msgs", sb.toString()).apply();
    }

    static String name(Context c) {
        return p(c).getString("name", "");
    }

    static void setName(Context c, String n) {
        p(c).edit().putString("name", n == null ? "" : n.trim()).apply();
    }

    static int interval(Context c) {
        int v = p(c).getInt("ms", 1000);
        if (v < MIN_MS) v = MIN_MS;
        if (v > MAX_MS) v = MAX_MS;
        return v;
    }

    static void setInterval(Context c, int ms) {
        p(c).edit().putInt("ms", Math.max(MIN_MS, Math.min(MAX_MS, ms))).apply();
    }

    /** Có nhập tên thì mỗi tin thành "Tên ơi, nội dung". */
    static String compose(Context c, String msg) {
        String n = name(c).trim();
        return n.isEmpty() ? msg : n + " ơi, " + msg;
    }

    static boolean loop(Context c) {
        return p(c).getBoolean("loop", false);
    }

    static void setLoop(Context c, boolean v) {
        p(c).edit().putBoolean("loop", v).apply();
    }

    static String fmtLong(int ms) {
        return String.format(Locale.US, "%.1f", ms / 1000f).replace('.', ',') + " giây";
    }

    static String fmt(int ms) {
        return String.format(Locale.US, "%.1f", ms / 1000f).replace('.', ',') + "s";
    }
}
