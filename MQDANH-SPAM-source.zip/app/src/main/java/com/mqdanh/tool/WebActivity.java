package com.mqdanh.tool;

import android.app.Activity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Đăng nhập bằng cookie ngay trong app (WebView) và điều khiển gửi tin tại đây. */
public class WebActivity extends Activity {

    private static final String DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Chrome/124.0.0.0 Safari/537.36";

    private final Handler h = new Handler(Looper.getMainLooper());
    private WebView web;
    private TextView status;
    private String sendJs = "";
    private boolean running = false;
    private int idx = 0;
    private int sent = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BLUE);

        String platform = getIntent().getStringExtra("platform");
        String raw = getIntent().getStringExtra("cookie");
        boolean zalo = !"messenger".equals(platform);

        List<String[]> cookies = parseCookies(raw == null ? "" : raw);
        if (cookies.isEmpty()) {
            Toast.makeText(this, "Cookie không hợp lệ", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        try (InputStream in = getAssets().open("send.js")) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            sendJs = new String(bo.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            Toast.makeText(this, "Thiếu file send.js", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        LinearLayout rootL = new LinearLayout(this);
        rootL.setOrientation(LinearLayout.VERTICAL);
        rootL.setBackgroundColor(0xFFFFFFFF);

        // thanh trên
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(Ui.BLUE);
        int tp = Ui.dp(this, 10);
        top.setPadding(tp, tp, tp, tp);
        TextView back = Ui.btn(this, "←", 0x33FFFFFF, 0xFFFFFFFF);
        back.setOnClickListener(v -> finish());
        top.addView(back);
        TextView title = new TextView(this);
        title.setText((zalo ? "Zalo" : "Messenger") + " · MQDANH SPAM");
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        title.setGravity(Gravity.CENTER);
        top.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView out = Ui.btn(this, "Đăng xuất", 0x33FFFFFF, 0xFFFFFFFF);
        out.setOnClickListener(v -> logout());
        top.addView(out);
        rootL.addView(top);

        // WebView
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString(DESKTOP_UA);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        rootL.addView(web, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // bảng điều khiển hồng
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pp = Ui.dp(this, 12);
        panel.setPadding(pp, pp, pp, pp);
        float r = Ui.dp(this, 22);
        GradientDrawable pbg = new GradientDrawable();
        pbg.setColor(Ui.PINK);
        pbg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        panel.setBackground(pbg);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView start = Ui.btn(this, "▶ Bắt đầu", 0xFFFFFFFF, Ui.PINK);
        TextView stop = Ui.btn(this, "■ Dừng", 0x55FFFFFF, 0xFFFFFFFF);
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        LinearLayout.LayoutParams c = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        c.leftMargin = Ui.dp(this, 8);
        row.addView(start, a);
        row.addView(stop, c);
        panel.addView(row);

        final TextView speed = new TextView(this);
        speed.setTextColor(0xFFFFFFFF);
        speed.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        speed.setText("Tốc độ: " + Cfg.fmt(Cfg.interval(this)));
        panel.addView(speed);
        SeekBar sb = new SeekBar(this);
        sb.setMax((Cfg.MAX_MS - Cfg.MIN_MS) / 100);
        sb.setProgress((Cfg.interval(this) - Cfg.MIN_MS) / 100);
        Ui.tint(sb, 0xFFFFFFFF, 0x66FFFFFF);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sk, int prog, boolean user) {
                int ms = Cfg.MIN_MS + prog * 100;
                Cfg.setInterval(WebActivity.this, ms);
                speed.setText("Tốc độ: " + Cfg.fmt(ms));
            }

            @Override
            public void onStartTrackingTouch(SeekBar sk) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sk) {
            }
        });
        panel.addView(sb);

        status = new TextView(this);
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        status.setText("Mở một cuộc trò chuyện rồi bấm Bắt đầu");
        panel.addView(status);
        rootL.addView(panel);

        start.setOnClickListener(v -> startRun());
        stop.setOnClickListener(v -> stopRun("Đã dừng"));

        setContentView(rootL);

        // nạp cookie rồi mở trang chat
        applyCookies(cookies, zalo);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.loadUrl(zalo ? "https://chat.zalo.me/" : "https://www.facebook.com/messages/");
    }

    // ---------------------------------------------------------------- cookie

    private List<String[]> parseCookies(String raw) {
        List<String[]> out = new ArrayList<>();
        raw = raw.trim();
        if (raw.startsWith("[")) {
            try {
                JSONArray arr = new JSONArray(raw);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    String n = o.optString("name");
                    if (!n.isEmpty()) out.add(new String[]{n, o.optString("value")});
                }
                return out;
            } catch (Exception ignored) {
            }
        }
        if (raw.toLowerCase().startsWith("cookie:")) raw = raw.substring(7);
        for (String part : raw.split("[;\\n\\r]+")) {
            int eq = part.indexOf('=');
            if (eq <= 0) continue;
            String n = part.substring(0, eq).trim();
            String v = part.substring(eq + 1).trim();
            if (!n.isEmpty()) out.add(new String[]{n, v});
        }
        return out;
    }

    private void applyCookies(List<String[]> cookies, boolean zalo) {
        String[][] targets = zalo
                ? new String[][]{{"https://chat.zalo.me", ".zalo.me"}, {"https://id.zalo.me", ".zalo.me"}}
                : new String[][]{{"https://www.facebook.com", ".facebook.com"},
                {"https://www.messenger.com", ".messenger.com"}};
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        for (String[] kv : cookies) {
            for (String[] t : targets) {
                String base = kv[0] + "=" + kv[1];
                cm.setCookie(t[0], base + "; Domain=" + t[1] + "; Path=/; Secure");
                cm.setCookie(t[0], base + "; Path=/; Secure");
            }
        }
        cm.flush();
    }

    private void logout() {
        stopRun("");
        CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(null);
        cm.flush();
        if (web != null) web.clearCache(true);
        Toast.makeText(this, "Đã đăng xuất", Toast.LENGTH_SHORT).show();
        finish();
    }

    // ---------------------------------------------------------------- gửi tin

    private void startRun() {
        if (Cfg.messages(this).isEmpty()) {
            status.setText("Chưa có tin nhắn — thêm ở màn hình chính");
            return;
        }
        if (running) return;
        running = true;
        idx = 0;
        sent = 0;
        status.setText("Đang chạy…");
        h.post(tick);
    }

    private void stopRun(String msg) {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (!msg.isEmpty() && status != null) status.setText(msg);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            List<String> l = Cfg.messages(WebActivity.this);
            if (l.isEmpty()) {
                stopRun("Chưa có tin nhắn — thêm ở màn hình chính");
                return;
            }
            String msg = Cfg.compose(WebActivity.this, l.get(idx % l.size()));
            idx++;
            String js = sendJs.replace("__TEXT__", JSONObject.quote(msg));
            web.evaluateJavascript(js, v -> {
                if (!running) return;
                if (v != null && v.contains("noinput")) {
                    status.setText("Chưa thấy ô nhập — hãy mở một cuộc trò chuyện");
                } else {
                    sent++;
                    status.setText("Đang chạy · đã gửi " + sent);
                }
            });
            h.postDelayed(this, Cfg.interval(WebActivity.this));
        }
    };

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
