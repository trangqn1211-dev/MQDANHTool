package com.mqdanh.tool;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class SenderService extends AccessibilityService {

    static SenderService instance;

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private View menu;
    private TextView status;
    private boolean running = false;
    private int idx = 0;
    private int sent = 0;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        stopRun("");
        removeMenu();
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    // ---------------------------------------------------------------- menu nổi

    void showMenu() {
        if (menu != null) return;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 10);
        box.setPadding(pad, pad, pad, pad);
        box.setBackground(Ui.rect(this, Ui.PINK, 22));

        // hàng tiêu đề: kéo để di chuyển + nút đóng
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("MQDANH SPAM");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        title.getPaint().setFakeBoldText(true);
        title.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = Ui.btn(this, "✕", 0x55FFFFFF, 0xFFFFFFFF);
        close.setPadding(Ui.dp(this, 12), Ui.dp(this, 4), Ui.dp(this, 12), Ui.dp(this, 4));
        head.addView(close);
        box.addView(head);

        // hàng nút
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView start = Ui.btn(this, "▶ Bắt đầu", 0xFFFFFFFF, Ui.PINK);
        TextView stop = Ui.btn(this, "■ Dừng", 0x55FFFFFF, 0xFFFFFFFF);
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        b.leftMargin = Ui.dp(this, 8);
        row.addView(start, a);
        row.addView(stop, b);
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rl.topMargin = Ui.dp(this, 6);
        box.addView(row, rl);

        // thanh tốc độ
        final TextView speed = new TextView(this);
        speed.setTextColor(0xFFFFFFFF);
        speed.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        speed.setText("Tốc độ: " + Cfg.fmt(Cfg.interval(this)));
        box.addView(speed);
        SeekBar sb = new SeekBar(this);
        sb.setMax((Cfg.MAX_MS - Cfg.MIN_MS) / 100);
        sb.setProgress((Cfg.interval(this) - Cfg.MIN_MS) / 100);
        Ui.tint(sb, 0xFFFFFFFF, 0x66FFFFFF);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int prog, boolean user) {
                int ms = Cfg.MIN_MS + prog * 100;
                Cfg.setInterval(SenderService.this, ms);
                speed.setText("Tốc độ: " + Cfg.fmt(ms));
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        box.addView(sb);

        status = new TextView(this);
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        status.setText("Sẵn sàng");
        box.addView(status);

        lp = new WindowManager.LayoutParams(
                Ui.dp(this, 250),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = Ui.dp(this, 20);
        lp.y = Ui.dp(this, 140);

        title.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = lp.x;
                        sy = lp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = sx + (int) (e.getRawX() - tx);
                        lp.y = sy + (int) (e.getRawY() - ty);
                        if (menu != null) wm.updateViewLayout(menu, lp);
                        return true;
                    default:
                        return false;
                }
            }
        });

        start.setOnClickListener(v -> startRun());
        stop.setOnClickListener(v -> stopRun("Đã dừng"));
        // Đóng menu = tắt tool luôn: dừng gửi + gỡ menu. Muốn dùng lại thì vào app bấm "Bật menu nổi".
        close.setOnClickListener(v -> {
            stopRun("");
            removeMenu();
            Toast.makeText(this, "Đã tắt MQDANH SPAM", Toast.LENGTH_SHORT).show();
        });

        menu = box;
        wm.addView(menu, lp);
    }

    private void removeMenu() {
        if (menu != null && wm != null) {
            try {
                wm.removeView(menu);
            } catch (Exception ignored) {
            }
        }
        menu = null;
        status = null;
    }

    private void setStatus(String s) {
        if (status != null) status.setText(s);
    }

    // ---------------------------------------------------------------- gửi tin

    private void startRun() {
        if (Cfg.messages(this).isEmpty()) {
            setStatus("Chưa có tin nhắn — vào app thêm");
            return;
        }
        if (running) return;
        running = true;
        idx = 0;
        sent = 0;
        setStatus("Đang chạy…");
        h.post(tick);
    }

    private void stopRun(String msg) {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (!msg.isEmpty()) setStatus(msg);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            List<String> l = Cfg.messages(SenderService.this);
            if (l.isEmpty()) {
                stopRun("Chưa có tin nhắn — vào app thêm");
                return;
            }
            if (!Cfg.loop(SenderService.this) && idx >= l.size()) {
                stopRun("Đã gửi xong danh sách");
                return;
            }
            String msg = Cfg.compose(SenderService.this, l.get(idx % l.size()));
            idx++;
            if (typeMessage(msg)) {
                h.postDelayed(sendClick, 60);
            } else {
                setStatus("Chưa thấy ô nhập — hãy chạm vào ô chat");
            }
            h.postDelayed(this, Cfg.interval(SenderService.this));
        }
    };

    private final Runnable sendClick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            if (clickSend()) {
                sent++;
                setStatus("Đang chạy · đã gửi " + sent);
            }
        }
    };

    private boolean typeMessage(String msg) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (n == null || !n.isEditable()) n = findEditable(root, 0);
        if (n == null) return false;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, msg);
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    private boolean clickSend() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo s = findSend(root, 0);
        if (s != null) {
            AccessibilityNodeInfo c = s;
            while (c != null && !c.isClickable()) c = c.getParent();
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        }
        if (Build.VERSION.SDK_INT >= 30) {
            AccessibilityNodeInfo in = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (in != null) {
                return in.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
            }
        }
        return false;
    }

    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 40) return null;
        if (n.isEditable() && n.isVisibleToUser()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findEditable(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    private AccessibilityNodeInfo findSend(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 40) return null;
        String id = n.getViewIdResourceName();
        boolean idHit = false;
        if (id != null) {
            String l = id.toLowerCase();
            idHit = l.endsWith("send") || l.contains("btn_send") || l.contains("send_btn")
                    || l.contains("send_button") || l.contains("sendbutton");
        }
        CharSequence cls = n.getClassName();
        boolean isBtn = cls != null && (cls.toString().contains("Button") || cls.toString().contains("ImageView"));
        if (idHit || isSendText(n.getContentDescription()) || (isBtn && isSendText(n.getText()))) {
            return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findSend(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    private boolean isSendText(CharSequence cs) {
        if (cs == null) return false;
        String s = cs.toString().trim().toLowerCase();
        return s.equals("gửi") || s.equals("gui") || s.equals("send") || s.equals("send message")
                || s.equals("gửi tin nhắn") || s.equals("press enter to send");
    }
}
