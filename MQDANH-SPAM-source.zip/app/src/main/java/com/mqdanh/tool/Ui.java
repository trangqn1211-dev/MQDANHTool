package com.mqdanh.tool;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.SeekBar;
import android.widget.TextView;

final class Ui {
    static final int BLUE = 0xFF0A84FF;
    static final int PINK = 0xFFFF4FA3;
    static final int INK = 0xFF0B2A5B;
    static final int FIELD = 0xFFEAF2FF;

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rect(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView btn(Context c, String text, int bg, int fg) {
        TextView b = new TextView(c);
        b.setText(text);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        b.setBackground(rect(c, bg, 14));
        b.setClickable(true);
        return b;
    }

    static void tint(SeekBar s, int color, int track) {
        s.setProgressTintList(ColorStateList.valueOf(color));
        s.setThumbTintList(ColorStateList.valueOf(color));
        s.setProgressBackgroundTintList(ColorStateList.valueOf(track));
    }
}
