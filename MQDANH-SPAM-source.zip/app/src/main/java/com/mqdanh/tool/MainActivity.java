package com.mqdanh.tool;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {

    private LinearLayout root;
    private LinearLayout listBox;
    private TextView speedLabel, svcStatus, btnZalo, btnMess;
    private EditText nameIn, msgIn, cookieIn;
    private String platform = "zalo";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF2E9BFF);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF2E9BFF, 0xFF0A4FD0}));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 18);
        root.setPadding(p, p, p, p * 2);
        sv.addView(root);

        buildHeader();
        buildMessageCard();
        buildSpeedCard();
        buildFloatCard();
        buildCookieCard();

        setContentView(sv);
        refreshList();
    }

    private void buildHeader() {
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logo.setClipToOutline(true);
        logo.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), Ui.dp(MainActivity.this, 18));
            }
        });
        LinearLayout.LayoutParams lpL = new LinearLayout.LayoutParams(Ui.dp(this, 80), Ui.dp(this, 80));
        lpL.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(logo, lpL);

        TextView title = new TextView(this);
        title.setText("MQDANH SPAM");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        title.getPaint().setFakeBoldText(true);
        title.setShadowLayer(6, 0, 3, 0x66000000);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 2));
        root.addView(title);

        root.addView(subLine("tiktok: @quajdaznh"));
        root.addView(subLine("telegram: @qdanhne"));
    }

    private TextView subLine(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xCCFFFFFF);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private LinearLayout card(String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        c.setPadding(p, p, p, p);
        c.setBackground(Ui.rect(this, 0xF2FFFFFF, 22));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 16);
        root.addView(c, lp);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(Ui.INK);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, 0, 0, Ui.dp(this, 8));
        c.addView(t);
        return c;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF7A8BA8);
        e.setTextColor(Ui.INK);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        e.setBackground(Ui.rect(this, Ui.FIELD, 12));
        int p = Ui.dp(this, 12);
        e.setPadding(p, p, p, p);
        return e;
    }

    private LinearLayout.LayoutParams match() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 8);
        return lp;
    }

    private void buildMessageCard() {
        LinearLayout c = card("Tin nhắn");

        nameIn = field("Tên (tự thêm vào đầu mỗi tin nhắn)");
        nameIn.setSingleLine(true);
        nameIn.setText(Cfg.name(this));
        c.addView(nameIn, match());

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        msgIn = field("Nhập nội dung tin nhắn");
        msgIn.setSingleLine(true);
        row.addView(msgIn, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView add = Ui.btn(this, "Thêm", Ui.BLUE, 0xFFFFFFFF);
        LinearLayout.LayoutParams la = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        la.leftMargin = Ui.dp(this, 8);
        row.addView(add, la);
        c.addView(row, match());

        add.setOnClickListener(v -> {
            String s = msgIn.getText().toString().trim();
            if (s.isEmpty()) return;
            List<String> l = Cfg.messages(this);
            l.add(s);
            Cfg.saveMessages(this, l);
            msgIn.setText("");
            refreshList();
        });

        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        c.addView(listBox, match());
    }

    private void refreshList() {
        listBox.removeAllViews();
        final List<String> l = Cfg.messages(this);
        if (l.isEmpty()) {
            TextView e = new TextView(this);
            e.setText("Chưa có tin nhắn nào");
            e.setTextColor(0xFF7A8BA8);
            listBox.addView(e);
            return;
        }
        for (int i = 0; i < l.size(); i++) {
            final int idx = i;
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setBackground(Ui.rect(this, 0xFFF4F8FF, 12));
            int p = Ui.dp(this, 10);
            r.setPadding(p, p, p, p);

            TextView t = new TextView(this);
            t.setText((i + 1) + ". " + l.get(i));
            t.setTextColor(Ui.INK);
            r.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

            TextView x = new TextView(this);
            x.setText("✕");
            x.setTextColor(0xFFE0245E);
            x.setTypeface(Typeface.DEFAULT_BOLD);
            x.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 4), 0);
            x.setOnClickListener(v -> {
                List<String> cur = Cfg.messages(this);
                if (idx < cur.size()) cur.remove(idx);
                Cfg.saveMessages(this, cur);
                refreshList();
            });
            r.addView(x);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(this, 6);
            listBox.addView(r, lp);
        }
    }

    private void buildSpeedCard() {
        LinearLayout c = card("Tốc độ gửi");
        speedLabel = new TextView(this);
        speedLabel.setTextColor(Ui.BLUE);
        speedLabel.setTypeface(Typeface.DEFAULT_BOLD);
        speedLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        c.addView(speedLabel);

        SeekBar sb = new SeekBar(this);
        sb.setMax((Cfg.MAX_MS - Cfg.MIN_MS) / 100);
        sb.setProgress((Cfg.interval(this) - Cfg.MIN_MS) / 100);
        Ui.tint(sb, Ui.BLUE, 0xFFC9DBFF);
        speedLabel.setText("Mỗi tin cách nhau " + Cfg.fmt(Cfg.interval(this)));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int prog, boolean user) {
                int ms = Cfg.MIN_MS + prog * 100;
                Cfg.setInterval(MainActivity.this, ms);
                speedLabel.setText("Mỗi tin cách nhau " + Cfg.fmt(ms));
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        c.addView(sb, match());
    }

    private void buildFloatCard() {
        LinearLayout c = card("Gửi trong app khác (menu nổi)");
        svcStatus = new TextView(this);
        svcStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        svcStatus.setTypeface(Typeface.DEFAULT_BOLD);
        c.addView(svcStatus);

        TextView open = Ui.btn(this, "Mở cài đặt trợ năng", 0xFFDCE9FF, Ui.BLUE);
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        c.addView(open, match());

        TextView show = Ui.btn(this, "Bật menu nổi", Ui.PINK, 0xFFFFFFFF);
        show.setOnClickListener(v -> {
            saveName();
            if (SenderService.instance == null) {
                toast("Hãy bật dịch vụ trợ năng MQDANH SPAM trước");
                return;
            }
            SenderService.instance.showMenu();
            moveTaskToBack(true);
        });
        c.addView(show, match());
    }

    private void buildCookieCard() {
        LinearLayout c = card("Đăng nhập bằng cookie");

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        btnZalo = Ui.btn(this, "Zalo", Ui.BLUE, 0xFFFFFFFF);
        btnMess = Ui.btn(this, "Messenger", Ui.FIELD, Ui.BLUE);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        l2.leftMargin = Ui.dp(this, 8);
        row.addView(btnZalo, l1);
        row.addView(btnMess, l2);
        c.addView(row, match());
        btnZalo.setOnClickListener(v -> pickPlatform("zalo"));
        btnMess.setOnClickListener(v -> pickPlatform("messenger"));

        cookieIn = field("Dán cookie Zalo / Messenger (a=b; c=d hoặc JSON)");
        cookieIn.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        cookieIn.setMinLines(3);
        cookieIn.setMaxLines(6);
        cookieIn.setGravity(Gravity.TOP | Gravity.START);
        c.addView(cookieIn, match());

        TextView go = Ui.btn(this, "Đăng nhập & điều khiển trong app", Ui.BLUE, 0xFFFFFFFF);
        go.setOnClickListener(v -> {
            String ck = cookieIn.getText().toString().trim();
            if (ck.isEmpty()) {
                toast("Hãy dán cookie vào ô trước");
                return;
            }
            saveName();
            Intent i = new Intent(this, WebActivity.class);
            i.putExtra("platform", platform);
            i.putExtra("cookie", ck);
            startActivity(i);
        });
        c.addView(go, match());
    }

    private void pickPlatform(String p) {
        platform = p;
        boolean z = p.equals("zalo");
        btnZalo.setBackground(Ui.rect(this, z ? Ui.BLUE : Ui.FIELD, 14));
        btnZalo.setTextColor(z ? 0xFFFFFFFF : Ui.BLUE);
        btnMess.setBackground(Ui.rect(this, z ? Ui.FIELD : Ui.BLUE, 14));
        btnMess.setTextColor(z ? Ui.BLUE : 0xFFFFFFFF);
    }

    private void saveName() {
        Cfg.setName(this, nameIn.getText().toString());
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean on = SenderService.instance != null;
        svcStatus.setText(on ? "● Trợ năng: đã bật" : "○ Trợ năng: chưa bật");
        svcStatus.setTextColor(on ? 0xFF1BA94C : 0xFFE0245E);
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveName();
    }
}
