package com.mqdanh.tool;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {

    private static final int GRAY = 0xFF8A8A8E;
    private static final int FIELD = 0xFFF2F2F7;

    private LinearLayout root;
    private LinearLayout listBox;
    private TextView speedLabel, svcStatus, btnZalo, btnMess;
    private EditText nameIn, msgIn, cookieIn;
    private String platform = "zalo";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFFD6E8FF);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFFD6E8FF, 0xFFF6F9FF}));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 18);
        root.setPadding(p, Ui.dp(this, 24), p, p * 2);
        sv.addView(root);

        buildHeader();
        buildContentCard();
        buildNameCard();
        buildListCard();
        buildSpeedCard();
        buildFloatArea();
        buildCookieCard();

        setContentView(sv);
        refreshList();
    }

    // ---------------------------------------------------------------- dựng UI

    private void buildHeader() {
        TextView title = new TextView(this);
        title.setText("MQDANH SPAM");
        title.setTextColor(0xFF111111);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 36);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        title.getPaint().setFakeBoldText(true);
        root.addView(title);
        root.addView(subLine("tiktok: @quajdaznh"));
        root.addView(subLine("telegram: @qdanhne"));
    }

    private TextView subLine(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Ui.BLUE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout card(String label) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 18);
        c.setPadding(p, p, p, p);
        c.setBackground(Ui.rect(this, 0xFFFFFFFF, 28));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 16);
        root.addView(c, lp);

        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(GRAY);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setPadding(0, 0, 0, Ui.dp(this, 6));
        c.addView(t);
        return c;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF8A8A8E);
        e.setTextColor(0xFF111111);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        e.setBackground(Ui.rect(this, FIELD, 22));
        int p = Ui.dp(this, 16);
        e.setPadding(p, Ui.dp(this, 14), p, Ui.dp(this, 14));
        return e;
    }

    private LinearLayout.LayoutParams match() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 10);
        return lp;
    }

    private TextView bigBtn(String text, int bg, int fg) {
        TextView t = Ui.btn(this, text, bg, fg);
        t.setBackground(Ui.rect(this, bg, 30));
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        t.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 16));
        return t;
    }

    private void buildContentCard() {
        LinearLayout c = card("NỘI DUNG");
        msgIn = field("Nhập tin nhắn...");
        msgIn.setSingleLine(true);
        c.addView(msgIn);

        TextView add = bigBtn("+ Thêm vào danh sách", Ui.BLUE, 0xFFFFFFFF);
        add.setOnClickListener(v -> {
            String s = msgIn.getText().toString().trim();
            if (s.isEmpty()) return;
            List<String> l = Cfg.messages(this);
            l.add(s);
            Cfg.saveMessages(this, l);
            msgIn.setText("");
            refreshList();
        });
        c.addView(add, match());
    }

    private void buildNameCard() {
        LinearLayout c = card("TÊN NGƯỜI NHẬN (tùy chọn)");
        nameIn = field("Nhập tên, ví dụ: Nam");
        nameIn.setSingleLine(true);
        nameIn.setText(Cfg.name(this));
        c.addView(nameIn);

        TextView hint = new TextView(this);
        hint.setText("Có nhập tên: mỗi tin thành \"Tên ơi, nội dung\".");
        hint.setTextColor(GRAY);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        c.addView(hint, match());
    }

    private void buildListCard() {
        LinearLayout c = card("DANH SÁCH (chạm để xóa)");
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        c.addView(listBox);
    }

    private void refreshList() {
        listBox.removeAllViews();
        final List<String> l = Cfg.messages(this);
        if (l.isEmpty()) {
            TextView e = new TextView(this);
            e.setText("Chưa có tin nhắn nào");
            e.setTextColor(GRAY);
            e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            listBox.addView(e);
            return;
        }
        for (int i = 0; i < l.size(); i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText((i + 1) + ". " + l.get(i));
            t.setTextColor(0xFF111111);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            t.setBackground(Ui.rect(this, FIELD, 16));
            int p = Ui.dp(this, 12);
            t.setPadding(p, p, p, p);
            t.setOnClickListener(v -> {
                List<String> cur = Cfg.messages(this);
                if (idx < cur.size()) cur.remove(idx);
                Cfg.saveMessages(this, cur);
                refreshList();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(this, 6);
            listBox.addView(t, lp);
        }
    }

    private void buildSpeedCard() {
        LinearLayout c = card("TỐC ĐỘ GỬI (0,2s – 10s)");
        speedLabel = new TextView(this);
        speedLabel.setTextColor(Ui.BLUE);
        speedLabel.setTypeface(Typeface.DEFAULT_BOLD);
        speedLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        speedLabel.setText(Cfg.fmtLong(Cfg.interval(this)));
        c.addView(speedLabel);

        SeekBar sb = new SeekBar(this);
        sb.setMax((Cfg.MAX_MS - Cfg.MIN_MS) / 100);
        sb.setProgress((Cfg.interval(this) - Cfg.MIN_MS) / 100);
        Ui.tint(sb, Ui.BLUE, 0xFFD9D9DE);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int prog, boolean user) {
                int ms = Cfg.MIN_MS + prog * 100;
                Cfg.setInterval(MainActivity.this, ms);
                speedLabel.setText(Cfg.fmtLong(ms));
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        c.addView(sb, match());

        Switch loop = new Switch(this);
        loop.setText("Lặp lại danh sách");
        loop.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        loop.setTextColor(0xFF111111);
        loop.setChecked(Cfg.loop(this));
        loop.setOnCheckedChangeListener((v, on) -> Cfg.setLoop(this, on));
        c.addView(loop, match());
    }

    private void buildFloatArea() {
        svcStatus = new TextView(this);
        svcStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        svcStatus.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sl = match();
        sl.topMargin = Ui.dp(this, 18);
        root.addView(svcStatus, sl);

        TextView open = bigBtn("Mở cài đặt Trợ năng", 0xFFDCE9FF, Ui.BLUE);
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(open, match());

        TextView show = bigBtn("Bật menu nổi", Ui.PINK, 0xFFFFFFFF);
        show.setOnClickListener(v -> {
            saveName();
            if (SenderService.instance == null) {
                toast("Hãy bật dịch vụ Trợ năng MQDANH SPAM trước");
                return;
            }
            SenderService.instance.showMenu();
            moveTaskToBack(true);
        });
        root.addView(show, match());
    }

    private void buildCookieCard() {
        LinearLayout c = card("ĐĂNG NHẬP BẰNG COOKIE");

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        btnZalo = Ui.btn(this, "Zalo", Ui.BLUE, 0xFFFFFFFF);
        btnMess = Ui.btn(this, "Messenger", FIELD, Ui.BLUE);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        l2.leftMargin = Ui.dp(this, 8);
        row.addView(btnZalo, l1);
        row.addView(btnMess, l2);
        c.addView(row);
        btnZalo.setOnClickListener(v -> pickPlatform("zalo"));
        btnMess.setOnClickListener(v -> pickPlatform("messenger"));

        cookieIn = field("Dán cookie Zalo / Messenger (a=b; c=d hoặc JSON)");
        cookieIn.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        cookieIn.setMinLines(3);
        cookieIn.setMaxLines(6);
        cookieIn.setGravity(Gravity.TOP | Gravity.START);
        c.addView(cookieIn, match());

        TextView go = bigBtn("Đăng nhập & điều khiển trong app", Ui.BLUE, 0xFFFFFFFF);
        go.setOnClickListener(v -> {
            String ck = cookieIn.getText().toString().trim();
            if (ck.isEmpty()) {
                toast("Hãy dán cookie vào ô trước");
                return;
            }
            saveName();
            Intent i = new Intent(this, WebActivity.class);
            i.putExtra("platform", platform);
            i.putExtra("cookie", ck);
            startActivity(i);
        });
        c.addView(go, match());
    }

    private void pickPlatform(String p) {
        platform = p;
        boolean z = p.equals("zalo");
        btnZalo.setBackground(Ui.rect(this, z ? Ui.BLUE : FIELD, 14));
        btnZalo.setTextColor(z ? 0xFFFFFFFF : Ui.BLUE);
        btnMess.setBackground(Ui.rect(this, z ? FIELD : Ui.BLUE, 14));
        btnMess.setTextColor(z ? Ui.BLUE : 0xFFFFFFFF);
    }

    private void saveName() {
        Cfg.setName(this, nameIn.getText().toString());
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean on = SenderService.instance != null;
        svcStatus.setText(on ? "● Dịch vụ Trợ năng đã bật" : "○ Chưa bật dịch vụ Trợ năng");
        svcStatus.setTextColor(on ? 0xFF1BA94C : 0xFF111111);
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveName();
    }
}
