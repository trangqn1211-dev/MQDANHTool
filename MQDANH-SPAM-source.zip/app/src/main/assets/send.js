(function (t) {
  try {
    var sels = ['#richInput', 'div[role="textbox"][contenteditable="true"]', 'div[contenteditable="true"]', 'textarea'];
    var el = null;
    for (var i = 0; i < sels.length && !el; i++) {
      var n = document.querySelectorAll(sels[i]);
      for (var j = n.length - 1; j >= 0; j--) {
        if (n[j].offsetParent !== null) { el = n[j]; break; }
      }
    }
    if (!el) return 'noinput';
    el.focus();
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      var d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
      d.set.call(el, t);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      document.execCommand('selectAll', false, null);
      document.execCommand('insertText', false, t);
    }
    setTimeout(function () {
      var b = document.querySelector('[aria-label="Press enter to send"],[aria-label="Send"],[aria-label="Gửi"],[aria-label="Nhấn Enter để gửi"]');
      if (b) { b.click(); return; }
      ['keydown', 'keypress', 'keyup'].forEach(function (k) {
        el.dispatchEvent(new KeyboardEvent(k, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
      });
    }, 40);
    return 'ok';
  } catch (e) { return 'err'; }
})(__TEXT__);
